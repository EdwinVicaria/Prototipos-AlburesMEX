<div>
    
    mostrar usuarios

    <div>
        <input type="text" wire:model="buscador">
        <button class="px-3 py-2 bg-yellow-300" wire:click="buscar()">Buscar</button>
    </div>
    <?php echo e($buscador); ?>


    <table class="table-auto">
        <thead>
            <tr>
                <th>nombre</th>
                <th>correo</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->email); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH C:\xampp\htdocs\Proyecto-UX\resources\views/livewire/show-users.blade.php ENDPATH**/ ?>