
<?php $__env->startSection('contenido'); ?>


<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('crear-user', [])->html();
} elseif ($_instance->childHasBeenRendered('yggkmce')) {
    $componentId = $_instance->getRenderedChildComponentId('yggkmce');
    $componentTag = $_instance->getRenderedChildComponentTagName('yggkmce');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('yggkmce');
} else {
    $response = \Livewire\Livewire::mount('crear-user', []);
    $html = $response->html();
    $_instance->logRenderedChild('yggkmce', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<br><br>
<div>
    <div class="relative overflow-x-auto shadow-md sm:rounded-lg">
        <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
            <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                <tr>
                    <th scope="col" class="px-6 py-3">
                        nombre
                    </th>
                    <th scope="col" class="px-6 py-3">
                        correo
                    </th>
                    
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                    <th scope="row" class="px-6 py-4 font-medium text-gray-900 dark:text-white whitespace-nowrap">
                        <?php echo e($user->name); ?>

                    </th>
                    <td class="px-6 py-4">
                        <?php echo e($user->email); ?>

                    </td>
                    <td class="px-6 py-4 text-right">
                        <a href="#" class="font-medium text-blue-600 dark:text-blue-500 hover:underline">Edit</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.inicio', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Proyecto-UX\resources\views/users/index.blade.php ENDPATH**/ ?>