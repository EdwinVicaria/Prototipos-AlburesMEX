<div>
    {{-- Care about people's approval and you will be their prisoner. --}}
    hola
    <button class="bg-yellow-300 px-3 py-3 my-5 mx-5">Registrar usuario</button>

    
</div>
