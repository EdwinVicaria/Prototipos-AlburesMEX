<?php return array (
  'crear-albur' => 'App\\Http\\Livewire\\CrearAlbur',
  'crear-user' => 'App\\Http\\Livewire\\CrearUser',
  'index-albur' => 'App\\Http\\Livewire\\IndexAlbur',
  'show-albur' => 'App\\Http\\Livewire\\ShowAlbur',
  'show-users' => 'App\\Http\\Livewire\\ShowUsers',
);