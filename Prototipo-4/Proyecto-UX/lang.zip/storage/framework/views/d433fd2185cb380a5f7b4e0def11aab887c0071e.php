<div>
    
    hola
    <button class="bg-yellow-300 px-3 py-3 my-5 mx-5">Registrar usuario</button>
</div>
<?php /**PATH C:\xampp\htdocs\Proyecto-UX\resources\views/livewire/crear-user.blade.php ENDPATH**/ ?>