 
<?php $__env->startSection('contenido'); ?>
<title>Esquemas</title>
<body>
    <nav class="border-gray-200 px-2 sm:px-4 py-7 rounded">
        <div class="container flex flex-wrap justify-between items-center mx-auto">
            <div class="hidden w-full md:block md:w-auto" id="mobile-menu">
                <ul class="flex flex-col mt-4 md:flex-row md:space-x-8 md:mt-0 md:text-sm md:font-medium">
                    <?php if(Auth()->user()): ?>
                    <li>
                        <a href="<?php echo e(route('dashboard')); ?>"
                            class="titulo ml-10 block py-2 pr-4 pl-3 text-white border-b border-gray-100 hover:bg-gray-50 md:hover:bg-red md:border-0 md:hover:text-blue-700 md:p-0 dark:text-black font-black md:dark:hover:text-red-500 dark:hover:bg-gray-700 dark:hover:text-black md:dark:hover:bg-transparent dark:border-gray-700">REGRESAR</a>
                    </li>
                    <?php else: ?>
                    <li>
                        <a href="<?php echo e(url('/')); ?>"
                            class="titulo ml-10 block py-2 pr-4 pl-3 text-black border-b border-gray-100 hover:bg-gray-50 md:hover:bg-red md:border-0 md:hover:text-blue-700 md:p-0 dark:text-black font-black md:dark:hover:text-red-500 dark:hover:bg-gray-700 dark:hover:text-black md:dark:hover:bg-transparent dark:border-gray-700">PAGINA
                            PRINCIPAL</a>
                    </li>
                    <?php endif; ?>
                    <!-- <li>
                                <a href="<?php echo e(route('nosotros')); ?>" class="titulo ml-10 block py-2 pr-4 pl-3 text-white border-b border-gray-100 hover:bg-gray-50 md:hover:bg-red md:border-0 md:hover:text-blue-700 md:p-0 dark:text-white font-black md:dark:hover:text-red-500 dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent dark:border-gray-700" aria-current="page">NOSOTROS</a>
                            </li> -->
                    <!-- <li>
                                <a href="" class="titulo ml-10 block py-2 pr-4 pl-3 text-white border-b border-gray-100 hover:bg-gray-50 md:hover:bg-red md:border-0 md:hover:text-blue-700 md:p-0 dark:text-white font-black md:dark:hover:text-red-500 dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent dark:border-gray-700">CONOCER MÁS</a>
                            </li> -->
                    <!-- <li>
                                <a href="<?php echo e(route('historia')); ?>" class="titulo ml-10 block py-2 pr-4 pl-3 text-white border-b border-gray-100 hover:bg-gray-50 md:hover:bg-red md:border-0 md:hover:text-blue-700 md:p-0 dark:text-white font-black md:dark:hover:text-red-500 dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent dark:border-gray-700">HISTORIA</a>
                            </li> -->
                    <li><a href="" class="ml-64"></a></li>
                    <?php if(Route::has('login')): ?>

                    <div class="">
                        <?php if(auth()->guard()->check()): ?>

                        <div class="dropdown relative ml-86">
                            <button class="text-black font-semibold rounded inline-flex items-center">
                                <span class="mr-1 titulo"><?php echo e(Auth::user()->name); ?></span>
                                <svg class="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg"
                                    viewBox="0 0 20 20">
                                    <path
                                        d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z" />
                                </svg>
                            </button>
                            <ul class="dropdown-menu absolute hidden text-gray-700 pt-1 w-28 content-center">
                                <form method="POST" action="<?php echo e(route('logout')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <li
                                        class="rounded-t bg-gray-200 hover:bg-gray-400 py-2 px-4 block whitespace-no-wrap">
                                        <a href="<?php echo e(route('miPerfil', Auth::user()->id)); ?>" class="titulo">PERFIL<span
                                                class="material-icons ml-5">account_circle</span></a>
                                    </li>

                                    <!-- <li>
                                                        <a href="<?php echo e(route('dashboard')); ?>" class="titulo rounded-t bg-gray-200 hover:bg-gray-400 py-2 px-4 block whitespace-no-wrap">PRINCIPAL</a>
                                                    </li> -->

                                    <li
                                        class="titulo rounded-t bg-gray-200 hover:bg-gray-400 py-2 px-4 block whitespace-no-wrap">
                                        <button>
                                            <a :href="route('logout')" onclick="event.preventDefault();
                                                                                    this.closest('form').submit();">
                                                <?php echo e(__('CERRAR SESIÓN')); ?>

                                            </a>
                                        </button>
                                    </li>
                                </form>
                            </ul>
                        </div>
                        <?php else: ?>
                        <div class="flex">
                            <?php if(Route::has('register')): ?>
                            <a href="<?php echo e(route('register')); ?>"
                                class="titulo ml-96 block py-2 pr-4 pl-3 text-white border-b border-gray-100 hover:bg-gray-50 md:hover:bg-transparent md:border-0 md:hover:text-blue-700 md:p-0 dark:text-black md:dark:hover:text-red dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent dark:border-gray-700">REGISTRARSE</a>
                            <?php endif; ?>
                            <a href="<?php echo e(route('login')); ?>"
                                class="titulo ml-5 block py-2 pr-4 pl-3 text-white border-b border-gray-100 hover:bg-gray-50 md:hover:bg-transparent md:border-0 md:hover:text-blue-700 md:p-0 dark:text-black md:dark:hover:text-red dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent dark:border-gray-700">INICIAR
                                SESIÓN</a>
                        </div>
                        <?php endif; ?>
                    </div>

                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
    <h1 class="text-center text-4xl font-black">Sabias que....</h1>
    <div class="flex">
        <img class="w-64" src="img/grafica1.png" alt="" />
        <h1 class="text-center text-4xl font-black mt-24">De los albures más usados en México el 72% son <b>Vúlgares</b> </h1>
    </div>
    <br>
    <h1 class="text-center text-4xl font-black">Resultados de los albures mas buscados</h1><br>
    <img  src="img/grafica2.png" alt="" /><br>
    <h1 class="text-center text-4xl font-black">albures más usados por los mexicanos</h1><br>
    <img  src="img/grafica3.png" alt="" />
</body>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.inicio', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Proyecto-UX\resources\views/esquema.blade.php ENDPATH**/ ?>