<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Error</title>

    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-black">

    <div class="container mx-auto">
        <div class="flex items-center justify-center w-screen h-screen">
            <div class="px-4 lg:py-12">
                <div class="lg:gap-4 lg:flex">

                        <div class="">
                            <img
                            src="https://sticker.nyc3.cdn.digitaloceanspaces.com/20210875/file_1737827_512x512.webp"
                            alt="img"
                            class="object-cover w-full h-full"
                            />
                        </div>

                        <div class="flex flex-col items-center justify-center md:py-24 lg:py-32">
                            <h1 class="font-bold text-blue-500 text-9xl animate-bounce">404</h1>
                            <p class="mb-2 text-3xl font-bold text-center text-yellow-500 md:text-3xl">
                            <span class="text-red-500 text-4xl">Oops!</span> <br>Lo sentimos ocurrio un problema
                            </p>
                            <p class="mb-8 text-center text-yellow-500 md:text-lg">
                                Pero a la larga te acostumbras
                            </p>
                            <a href="<?php echo e(url('/')); ?>" class="px-6 py-2 text-sm font-semibold text-black-500 bg-red-500 rounded-lg animate-pulse">
                                Volver
                            </a>
                        </div>
                </div>
            </div>
        </div>   
    </div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\Proyecto-UX\vendor\laravel\framework\src\Illuminate\Foundation\Exceptions/views/404.blade.php ENDPATH**/ ?>