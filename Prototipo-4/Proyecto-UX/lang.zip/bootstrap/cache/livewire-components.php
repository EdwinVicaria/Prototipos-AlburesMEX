<?php return array (
  'crear-albur' => 'App\\Http\\Livewire\\CrearAlbur',
  'crear-user' => 'App\\Http\\Livewire\\CrearUser',
  'editar-albur' => 'App\\Http\\Livewire\\EditarAlbur',
  'index-albur' => 'App\\Http\\Livewire\\IndexAlbur',
  'perfil' => 'App\\Http\\Livewire\\Perfil',
  'show-albur' => 'App\\Http\\Livewire\\ShowAlbur',
  'show-users' => 'App\\Http\\Livewire\\ShowUsers',
);