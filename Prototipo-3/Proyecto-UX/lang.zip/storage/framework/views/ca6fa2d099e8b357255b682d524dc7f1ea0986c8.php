
<?php $__env->startSection('contenido'); ?>
<h1>ESQUEMAS</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.inicio', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Proyecto-UX\resources\views/esquema.blade.php ENDPATH**/ ?>