@extends('layouts.inicio')
@section('contenido')
<h1>ESQUEMAS</h1>
@endsection