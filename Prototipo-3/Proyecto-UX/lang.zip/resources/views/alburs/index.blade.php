@extends('layouts.app')
@section('contenido')



<livewire:show-albur>




@endsection


